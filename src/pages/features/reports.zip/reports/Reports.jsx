import React, { useState } from 'react';
import ReportDashboard from './ReportDashboard';
import CustomReportGenerator from './CustomReportGenerator';
import './Reports.css';

const Reports = () => {
  const [tab, setTab] = useState('dashboard');

  return (
    <div className="reports-container">
      <h2>Reports & Analytics</h2>

      <div className="tab-navbar">
        <button
          className={tab === 'dashboard' ? 'tab-btn active' : 'tab-btn'}
          onClick={() => setTab('dashboard')}
        >
          Dashboard
        </button>

        <button
          className={tab === 'custom' ? 'tab-btn active' : 'tab-btn'}
          onClick={() => setTab('custom')}
        >
          Custom Report
        </button>
      </div>

      <div className="tab-content">
        {tab === 'dashboard' && <ReportDashboard />}
        {tab === 'custom' && <CustomReportGenerator />}
      </div>
    </div>
  );
};

export default Reports;
